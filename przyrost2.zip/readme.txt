Jak uruchomi�:
1. Uruchomi� w intellij.
2. Zapytania wprowadza� poprzez Postmana (np. GET	http://localhost:8080/api/positions/save/json/4)



Model danych znajduje si� w klasach:
Address
Contact
Employee
Position

Zapytania znajduj� si� w klasach:
AddressController
ContactController
EmployeeController
PositionController

ZonedDateTime znajduje si� w klasie Task, kt�ra ostatecznie nie zosta�a u�yta w projekcie.


"Docelowy projekt powinien czyta� i zapisywa� zamodelowane dane z i do plik�w typu XML i JSON (obu typ�w!) i zapisywa�/odczytywa� je z bazy danych."
Serializacja znajduje si� w klasach zapyta� (AddressController, ContactController, EmployeeController, PositionController).
