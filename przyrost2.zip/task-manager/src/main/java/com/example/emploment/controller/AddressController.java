package com.example.emploment.controller;

import com.example.emploment.model.Contract;
import com.example.emploment.repository.AddressRepository;
import com.example.emploment.model.Address;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.io.File;
import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/api")
public class AddressController {

    @Autowired
    AddressRepository addressRepository;

    // Get All Addresses
    @RequestMapping(value = "/addresses", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Address> getAllAddresses() {
        return addressRepository.findAll();
    }

    // Create a address
    @RequestMapping(value = "/addresses", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public Address createAddress(@Valid @RequestBody Address address) {
        return addressRepository.save(address);
    }

    // Get a Single address
    @RequestMapping(value = "/addresses/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Address> getAddressById(@PathVariable(value="id") Long addressId) {
        Address address = addressRepository.findOne(addressId);
        if (address == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok().body(address);
    }
    // Update a address
    @RequestMapping(value = "/addresses/{id}", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Address> updateAddress(@PathVariable(value = "id") Long addressId,
                                                   @Valid @RequestBody Address addressDetails) {
        Address address = addressRepository.findOne(addressId);
        if(address == null) {
            return ResponseEntity.notFound().build();
        }
        address.setAddressline1(addressDetails.getAddressline1());
        address.setAddressline2(addressDetails.getAddressline2());
        address.setCity(addressDetails.getCity());
        address.setPostCode(addressDetails.getPostCode());

        Address updateAddress = addressRepository.save(address);
        return ResponseEntity.ok(updateAddress);
    }

    // Delete a address
    @RequestMapping(value = "/addresses/{id}", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Address> deleteAddress(@PathVariable(value = "id") Long positionsId) {
        Address address = addressRepository.findOne(positionsId);
        if(address == null) {
            return ResponseEntity.notFound().build();
        }

        addressRepository.delete(address);
        return ResponseEntity.ok().build();
    }
    // save address to json
    @RequestMapping(value = "/addresses/save/json/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public boolean SaveAddresstToJson(@PathVariable(value = "id") Long addressId) {
        Address address = addressRepository.findOne(addressId);
        try {
            ObjectMapper mapper = new ObjectMapper();
            mapper.registerModule(new JavaTimeModule());
            mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            mapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
            //Object to JSON in file
            mapper.writeValue(new File("address_id_" + addressId + ".json"), address);
            return true;
        } catch (JsonGenerationException e) {
            e.printStackTrace();
            return false;
        } catch (JsonMappingException e) {
            e.printStackTrace();
            return false;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    // read address from json and save
    @RequestMapping(value = "/addresses/readandsave/json/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public boolean ReadandSaveAddressFromJson(@PathVariable(value = "id") Long addressID) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            //JSON from file to Object
            mapper.registerModule(new JavaTimeModule());
            mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            mapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
            Address address = mapper.readValue(new File("address_id_" + addressID + ".json"), Address.class);
            addressRepository.save(address);
            return true;
        } catch (JsonGenerationException e) {
            e.printStackTrace();
            return false;
        } catch (JsonMappingException e) {
            e.printStackTrace();
            return false;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    // save address to xml
    @RequestMapping(value = "/addresses/save/xml/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public boolean SaveAddressToXml(@PathVariable(value = "id") Long addressId) {
        Address address = addressRepository.findOne(addressId);
        try {
            ObjectMapper xmlMapper = new XmlMapper();
            xmlMapper.registerModule(new JavaTimeModule());
            xmlMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
            //Object to XML in file
            String xml = xmlMapper.writeValueAsString(address);
            xmlMapper.writeValue(new File("address_id_" + addressId + ".xml"), address);
            return true;
        } catch (JsonMappingException e) {
            e.printStackTrace();
            return false;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    // read and save address to xml
    @RequestMapping(value = "/addresses/readandsave/xml/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public boolean ReadandSaveAddressFromXML(@PathVariable(value = "id") Long addressId) {
        try {
            ObjectMapper xmlMapper = new XmlMapper();
            xmlMapper.registerModule(new JavaTimeModule());
            xmlMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
            //Object to XML in file
            Address address = xmlMapper.readValue(new File("address_id_" + addressId + ".xml"), Address.class);
            addressRepository.save(address);
            return true;
        } catch (JsonMappingException e) {
            e.printStackTrace();
            return false;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

}
