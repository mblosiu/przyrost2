package com.example.emploment.controller;

import com.example.emploment.model.Contract;
import com.example.emploment.repository.ContractsRepository;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.io.File;
import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/api")
public class ContractController {

    @Autowired
    ContractsRepository contractRepository;

    // Get All positions
    @RequestMapping(value = "/contracts", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Contract> getAllContracts() {
        return contractRepository.findAll();
    }

    // Create a positionAddressController
    @RequestMapping(value = "/contracts", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public Contract createContract(@Valid @RequestBody Contract contract) {
        return contractRepository.save(contract);
    }

    // Get a Single position
    @RequestMapping(value = "/contracts/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Contract> getContractById(@PathVariable(value = "id") Long contractId) {
        Contract contract = contractRepository.findOne(contractId);
        if (contract == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok().body(contract);
    }

    // Update a position
    @RequestMapping(value = "/contracts/{id}", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Contract> updateContract(@PathVariable(value = "id") Long contractId,
                                                   @Valid @RequestBody Contract contractDetails) {
        Contract contract = contractRepository.findOne(contractId);
        if (contract == null) {
            return ResponseEntity.notFound().build();
        }
        contract.setDescription(contractDetails.getDescription());
        contract.setSallary(contractDetails.getSallary());
        contract.setInitialDateOfContract(contractDetails.getInitialDateOfContract());
        contract.setEndDateOfContract(contractDetails.getEndDateOfContract());
        contract.setPosition(contractDetails.getPosition());
        Contract updatePosition = contractRepository.save(contract);
        return ResponseEntity.ok(updatePosition);
    }

    // Delete a contract
    @RequestMapping(value = "/contracts/{id}", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Contract> deleteContract(@PathVariable(value = "id") Long contractId) {
        Contract contract = contractRepository.findOne(contractId);
        if (contract == null) {
            return ResponseEntity.notFound().build();
        }

        contractRepository.delete(contract);
        return ResponseEntity.ok().build();
    }

    // contracts where sallary less than
    @RequestMapping(value = "/contracts/sallarylessthan/{amount}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Contract> findBySalaryLessThan(@PathVariable(value = "amount") Double amount) {
        return contractRepository.findBySallaryLessThan(amount);
    }

    // save contract to json
    @RequestMapping(value = "/contracts/save/json/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public boolean SaveContractToJson(@PathVariable(value = "id") Long contractId) {
        Contract contract = contractRepository.findOne(contractId);
        try {
            ObjectMapper mapper = new ObjectMapper();
            mapper.registerModule(new JavaTimeModule());
            mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            mapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
            //Object to JSON in file
            mapper.writeValue(new File("contract_id_" + contractId + ".json"), contract);
            return true;
        } catch (JsonGenerationException e) {
            e.printStackTrace();
            return false;
        } catch (JsonMappingException e) {
            e.printStackTrace();
            return false;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    // read contract from json and save
    @RequestMapping(value = "/contracts/readandsave/json/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public boolean ReadandSaveContractFromJson(@PathVariable(value = "id") Long contractId) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            //JSON from file to Object
            mapper.registerModule(new JavaTimeModule());
            mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            mapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
            Contract contract = mapper.readValue(new File("contract_id_" + contractId + ".json"), Contract.class);
            //contract.setContract_id((long) 21);
            contractRepository.save(contract);
            return true;
        } catch (JsonGenerationException e) {
            e.printStackTrace();
            return false;
        } catch (JsonMappingException e) {
            e.printStackTrace();
            return false;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    // save contract to xml
    @RequestMapping(value = "/contracts/save/xml/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public boolean SaveContractToXml(@PathVariable(value = "id") Long contractId) {
        Contract contract = contractRepository.findOne(contractId);
        try {
            ObjectMapper xmlMapper = new XmlMapper();
            xmlMapper.registerModule(new JavaTimeModule());
            xmlMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
            //Object to XML in file
            String xml = xmlMapper.writeValueAsString(contract);
            // File file = new File("contract_id_" + contractId + ".xml",xml);
            xmlMapper.writeValue(new File("contract_id_" + contractId + ".xml"), contract);
            return true;
        } catch (JsonMappingException e) {
            e.printStackTrace();
            return false;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    // read and save contract to xml
    @RequestMapping(value = "/contracts/readandsave/xml/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public boolean ReadandSaveContractFromXML(@PathVariable(value = "id") Long contractId) {
        try {
            ObjectMapper xmlMapper = new XmlMapper();
            xmlMapper.registerModule(new JavaTimeModule());
            xmlMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
            //Object to XML in file
            Contract contract = xmlMapper.readValue(new File("contract_id_" + contractId + ".xml"), Contract.class);
            contractRepository.save(contract);
            return true;
        } catch (JsonMappingException e) {
            e.printStackTrace();
            return false;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }
}

