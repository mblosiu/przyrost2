package com.example.emploment.controller;

import com.example.emploment.model.Address;
import com.example.emploment.model.Employee;
import com.example.emploment.repository.EmployeeRepository;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api")
public class EmployeeController {

    @Autowired
    EmployeeRepository employeeRepository;

    // Get All employees
    @RequestMapping(value = "/employees", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    // Create a employee
    @RequestMapping(value = "/employees", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public Employee createAddress(@Valid @RequestBody Employee employee) {
        return employeeRepository.save(employee);
    }

    // Get a Single employee
    @RequestMapping(value = "/employees/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Employee> getEmployeeById(@PathVariable(value="id") Long employeeId) {
        Employee employee = employeeRepository.findOne(employeeId);
        if (employee == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok().body(employee);
    }
    // Update a employee
    @RequestMapping(value = "/employees/{id}", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Employee> updateEmployee(@PathVariable(value = "id") Long addressId,
                                                   @Valid @RequestBody Employee employeeDetails) {
        Employee employee = employeeRepository.findOne(addressId);
        if(employee == null) {
            return ResponseEntity.notFound().build();
        }
        employee.setFirstName(employeeDetails.getFirstName());
        employee.setLastName(employeeDetails.getLastName());
        employee.setEmail(employeeDetails.getEmail());
        employee.setPhone(employeeDetails.getPhone());
        employee.setAddress(employeeDetails.getAddress());
        employee.setContract(employeeDetails.getContract());

        Employee updateAddress = employeeRepository.save(employee);
        return ResponseEntity.ok(updateAddress);
    }

    // Delete a employee
    @RequestMapping(value = "/employees/{id}", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Employee> deletEmployee(@PathVariable(value = "id") Long employeeId) {
        Employee employee = employeeRepository.findOne(employeeId);
        if(employee == null) {
            return ResponseEntity.notFound().build();
        }

        employeeRepository.delete(employee);
        return ResponseEntity.ok().build();
    }

    // contracts where sallary less than
    @RequestMapping(value = "/employees/findbylastname/{lastname}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Employee> findBylastName(@PathVariable(value = "lastname") String lastname) {
        return employeeRepository.findBylastName(lastname);
    }

    @RequestMapping(value = "/employees_list/{page}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public Iterable<Employee> list(@PathVariable("page") Integer pageNr,@RequestParam("size") Optional<Integer> howManyOnPage) {
        return employeeRepository.findAll(new PageRequest(pageNr,howManyOnPage.orElse(2)));
    }

    // return count of employees
    @RequestMapping(value = "/employees/count/", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public Integer countEmployee() {
        return employeeRepository.countEmployee();
    }

    // return count of employees
    @RequestMapping(value = "/employees/avg_sallary/", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public Double AvarageSallaryForEmployee() {
        return employeeRepository.AvarageSallaryForEmployee();
    }

    // save employee to json
    @RequestMapping(value = "/employees/save/json/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public boolean SaveEmployeeToJson(@PathVariable(value = "id") Long employeeId) {
        Employee employee = employeeRepository.findOne(employeeId);
        try {
            ObjectMapper mapper = new ObjectMapper();
            mapper.registerModule(new JavaTimeModule());
            mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            mapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
            //Object to JSON in file
            mapper.writeValue(new File("employee_id_" + employeeId + ".json"), employee);
            return true;
        } catch (JsonGenerationException e) {
            e.printStackTrace();
            return false;
        } catch (JsonMappingException e) {
            e.printStackTrace();
            return false;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    // read employee from json and save
    @RequestMapping(value = "/employees/readandsave/json/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public boolean ReadandSaveEmployeeFromJson(@PathVariable(value = "id") Long employeeId) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            //JSON from file to Object
            mapper.registerModule(new JavaTimeModule());
            mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            mapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
            Employee employee = mapper.readValue(new File("employee_id_" + employeeId + ".json"), Employee.class);
            employeeRepository.save(employee);
            return true;
        } catch (JsonGenerationException e) {
            e.printStackTrace();
            return false;
        } catch (JsonMappingException e) {
            e.printStackTrace();
            return false;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    // save employee to xml
    @RequestMapping(value = "/employees/save/xml/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public boolean SaveEmployeeToXml(@PathVariable(value = "id") Long employeeId) {
        Employee employee = employeeRepository.findOne(employeeId);
        try {
            ObjectMapper xmlMapper = new XmlMapper();
            xmlMapper.registerModule(new JavaTimeModule());
            xmlMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
            //Object to XML in file
            String xml = xmlMapper.writeValueAsString(employee);
            xmlMapper.writeValue(new File("employee_id_" + employeeId + ".xml"), employee);
            return true;
        } catch (JsonMappingException e) {
            e.printStackTrace();
            return false;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    // read and save employee to xml
    @RequestMapping(value = "/employees/readandsave/xml/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public boolean ReadandSaveEmployeeFromXML(@PathVariable(value = "id") Long employeeId) {
        try {
            ObjectMapper xmlMapper = new XmlMapper();
            xmlMapper.registerModule(new JavaTimeModule());
            xmlMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
            //Object to XML in file
            Employee employee = xmlMapper.readValue(new File("employee_id_" + employeeId + ".xml"), Employee.class);
            employeeRepository.save(employee);
            return true;
        } catch (JsonMappingException e) {
            e.printStackTrace();
            return false;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

}
