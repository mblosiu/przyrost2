package com.example.emploment.controller;

import com.example.emploment.model.Address;
import com.example.emploment.model.Position;
import com.example.emploment.repository.PositionRepository;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.io.File;
import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/api")
public class PositionController {

    @Autowired
    PositionRepository positionRepository;
    // Get All positions
    @RequestMapping(value = "/positions", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Position> getAllPositions() {
        return positionRepository.findAll();
    }

    // Create a position
    @RequestMapping(value = "/positions", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public Position createPosition(@Valid @RequestBody Position positions) {
        return positionRepository.save(positions);
    }
    // Get a Single position
    @RequestMapping(value = "/positions/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Position> getPositionById(@PathVariable(value="id") Long positionsId) {
        Position position = positionRepository.findOne(positionsId);
        if (position == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok().body(position);
    }

    // Update a position
    @RequestMapping(value = "/positions/{id}", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Position> updatePosition(@PathVariable(value = "id") Long positionId,
                                           @Valid @RequestBody Position positionDetails) {
        Position position = positionRepository.findOne(positionId);
        if(position == null) {
            return ResponseEntity.notFound().build();
        }
        position.setName(positionDetails.getName());
        position.setBasedSallary(positionDetails.getBasedSallary());

        Position updatePosition = positionRepository.save(position);
        return ResponseEntity.ok(updatePosition);
    }

    // Delete a position
    @RequestMapping(value = "/positions/{id}", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Position> deleteNote(@PathVariable(value = "id") Long positionsId) {
        Position position = positionRepository.findOne(positionsId);
        if(position == null) {
            return ResponseEntity.notFound().build();
        }

        positionRepository.delete(position);
        return ResponseEntity.ok().build();
    }

    // contracts where sallary greater than
    @RequestMapping(value = "/positions/sallarygreaterthan/{amount}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Position> findBybasedSallaryGreaterThan(@PathVariable(value = "amount") Double amount) {
        return positionRepository.findBybasedSallaryGreaterThan(amount);
    }

    // save position to json
    @RequestMapping(value = "/positions/save/json/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public boolean SavePositionToJson(@PathVariable(value = "id") Long positionId) {
        Position position = positionRepository.findOne(positionId);
        try {
            ObjectMapper mapper = new ObjectMapper();
            mapper.registerModule(new JavaTimeModule());
            mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            mapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
            //Object to JSON in file
            mapper.writeValue(new File("position_id_" + positionId + ".json"), position);
            return true;
        } catch (JsonGenerationException e) {
            e.printStackTrace();
            return false;
        } catch (JsonMappingException e) {
            e.printStackTrace();
            return false;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    // read position from json and save
    @RequestMapping(value = "/positions/readandsave/json/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public boolean ReadandSavePositionFromJson(@PathVariable(value = "id") Long positionId) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            //JSON from file to Object
            mapper.registerModule(new JavaTimeModule());
            mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            mapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
            Position postion = mapper.readValue(new File("position_id_" + positionId + ".json"), Position.class);
            positionRepository.save(postion);
            return true;
        } catch (JsonGenerationException e) {
            e.printStackTrace();
            return false;
        } catch (JsonMappingException e) {
            e.printStackTrace();
            return false;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    // save position to xml
    @RequestMapping(value = "/positions/save/xml/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public boolean SavePositionToXml(@PathVariable(value = "id") Long positionId) {
        Position position = positionRepository.findOne(positionId);
        try {
            ObjectMapper xmlMapper = new XmlMapper();
            xmlMapper.registerModule(new JavaTimeModule());
            xmlMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
            //Object to XML in file
            String xml = xmlMapper.writeValueAsString(position);
            xmlMapper.writeValue(new File("position_id_" + positionId + ".xml"), position);
            return true;
        } catch (JsonMappingException e) {
            e.printStackTrace();
            return false;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    // read and save position to xml
    @RequestMapping(value = "/positions/readandsave/xml/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public boolean ReadandSavePositionFromXML(@PathVariable(value = "id") Long positionID) {
        try {
            ObjectMapper xmlMapper = new XmlMapper();
            xmlMapper.registerModule(new JavaTimeModule());
            xmlMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
            //Object to XML in file
            Position position = xmlMapper.readValue(new File("position_id_" + positionID + ".xml"), Position.class);
            positionRepository.save(position);
            return true;
        } catch (JsonMappingException e) {
            e.printStackTrace();
            return false;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

}
