package com.example.emploment.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import org.hibernate.validator.constraints.NotBlank;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import javax.persistence.*;
import java.io.Serializable;
import java.time.ZonedDateTime;


@Entity
@Table(name = "contracts")
@EntityListeners(AuditingEntityListener.class)
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Contract implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long contract_id;

    @Column(name = "description", length = 255)
    @NotBlank
    private String description;


    @Column(name = "sallary")
    private Double sallary;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ")
    @Column(nullable = false, updatable = false)
    @CreatedDate
    private ZonedDateTime initialDateOfContract;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ")
    @Column(nullable = false, updatable = false)
    @CreatedDate
    private ZonedDateTime endDateOfContract;

    @ManyToOne
    @JoinColumn(name = "position_id")
    private Position position;



    public Long getContract_id() {
        return contract_id;
    }

    public void setContract_id(Long contract_id) {
        this.contract_id = contract_id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Double getSallary() {
        return sallary;
    }

    public void setSallary(Double sallary) {
        this.sallary = sallary;
    }

    public ZonedDateTime getInitialDateOfContract() {
        return initialDateOfContract;
    }

    public void setInitialDateOfContract(ZonedDateTime initialDateOfContract) {
        this.initialDateOfContract = initialDateOfContract;
    }

    public ZonedDateTime getEndDateOfContract() {
        return endDateOfContract;
    }

    public void setEndDateOfContract(ZonedDateTime endDateOfContract) {
        this.endDateOfContract = endDateOfContract;
    }

    public Position getPosition() {
        return position;
    }

    public void setPosition(Position position) {
        this.position = position;
    }

}