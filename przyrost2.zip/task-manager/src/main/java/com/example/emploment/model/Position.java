package com.example.emploment.model;

import org.hibernate.validator.constraints.NotBlank;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

@Entity
@Table(name = "position")
@EntityListeners(AuditingEntityListener.class)
public class Position implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long position_id;

    @Column(name = "name", length = 255)
    @NotBlank
    private String name;

    @Column(name = "basedSallary")
    private Double basedSallary;

    @OneToMany(mappedBy = "position")
    private List<Contract> contracts;

    public Long getPosition_id() {
        return position_id;
    }

    public void setPosition_id(Long position_id) {
        this.position_id = position_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getBasedSallary() {
        return basedSallary;
    }

    public void setBasedSallary(Double basedSallary) {
        this.basedSallary = basedSallary;
    }
}

