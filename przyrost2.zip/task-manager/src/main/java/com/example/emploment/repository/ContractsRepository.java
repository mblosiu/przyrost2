package com.example.emploment.repository;

import com.example.emploment.model.Contract;
import com.example.emploment.model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ContractsRepository extends JpaRepository<Contract, Long>{
    public List<Contract> findBySallaryLessThan(Double sallary);
}
